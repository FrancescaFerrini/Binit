//
//  LearnMenu.swift
//  Game Buster
//
//  Created by Fernando Sensenhauser on 12/12/23.
//

import Foundation
import SpriteKit

class LearnMenu: SKScene {
    
    
}
