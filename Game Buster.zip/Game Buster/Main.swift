//
//  Main.swift
//  Game Buster
//
//  Created by Francesca Ferrini on 10/12/23.
//

import SwiftUI

@main
struct Main: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
