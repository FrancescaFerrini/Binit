//
//  PauseView.swift
//  Game Buster
//
//  Created by Francesca Ferrini on 15/12/23.
//

import SwiftUI
import SpriteKit


class PauseView: SKScene{
    
    let messagePause: SKSpriteNode!
    
}



